import { auth, app } from "./config_firebase.js";
import { signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-auth.js";
import {FacebookAuthProvider, GoogleAuthProvider, signInWithPopup, signOut } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-auth.js";
//add domain 127.0.0 for local host
const Googleprovider = new GoogleAuthProvider();
const Facebookprovider = new FacebookAuthProvider();
const inputEmail = document.querySelector("#email");
const inputPass = document.getElementById("password");
const LoginForm = document.querySelector("#LoginForm");
// ✅ Email/password login
const handleLogIN = function (event) {
  event.preventDefault();
  const email = inputEmail.value;
  const password = inputPass.value;

  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      const user = userCredential.user;
      // ✅ Thống nhất dùng sessionStorage
      const userSession = {
        user: user.email,
        expiryTime: new Date().getTime() + 60 * 60 * 1000
      };
      sessionStorage.setItem("userSession", JSON.stringify(userSession));
      alert("Đăng nhập thành công");
      window.location.href = "index.html";
    })
    .catch((error) => {
      alert("Đăng nhập thất bại: " + error.message);
    });
};

// ✅ Google login — chỉ gọi khi click button
const ggbtn = document.querySelector(".login-with-google-btn");
ggbtn.addEventListener("click", function () {
  signInWithPopup(auth, Googleprovider)
    .then((result) => {
      const user = result.user;
      // ✅ Thống nhất dùng sessionStorage
      const userSession = {
        user: user.displayName || user.email,
        expiryTime: new Date().getTime() + 60 * 60 * 1000
      };
      sessionStorage.setItem("userSession", JSON.stringify(userSession));
      alert("Welcome " + (user.displayName || user.email));
      window.location.href = "index.html";
    })
    .catch((error) => {
      alert("Đăng nhập Google thất bại: " + error.message);
    });
});
const fbbtn = document.querySelector(".login-with-facebook-btn");
fbbtn.addEventListener("click", function () {
  signInWithPopup(auth, Facebookprovider)
    .then((result) => {
      const user = result.user;
      // ✅ Thống nhất dùng sessionStorage
      const userSession = {
        user: user.displayName || user.email,
        expiryTime: new Date().getTime() + 60 * 60 * 1000
      };
      sessionStorage.setItem("userSession", JSON.stringify(userSession));
      alert("Welcome " + (user.displayName || user.email));
      window.location.href = "index.html";
    })
    .catch((error) => {
      alert("Đăng nhập Facebook thất bại: " + error.message);
    });
});

LoginForm.addEventListener("submit", handleLogIN);