// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-analytics.js";

import { getAuth } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-firestore.js";


// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries --> cái này làm cho auth + db

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCU1DooFSBAW1omXR32o91adL1hfl3vluk",
  authDomain: "to-69-86f1e.firebaseapp.com",
  projectId: "to-69-86f1e",
  storageBucket: "to-69-86f1e.firebasestorage.app",
  messagingSenderId: "68058494021",
  appId: "1:68058494021:web:ed8a2ae8e5643bae4bdf2c",
  measurementId: "G-3516YC6HLF"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);
const db = getFirestore(app);
export { auth, db };
export { app, analytics };