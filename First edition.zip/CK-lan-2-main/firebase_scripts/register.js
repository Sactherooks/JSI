import { auth, db } from "./config_firebase.js";
import { collection, addDoc } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-firestore.js";
import { createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-auth.js";

const inputUser = document.querySelector("#username");
const inputEmail = document.querySelector("#email");
const inputPass = document.getElementById("password");
const confirminputpassova = document.getElementById("confirmPassword");
const registForm = document.querySelector("#registerForm");
const handleRegister = function (event) {
    event.preventDefault();
    let username = inputUser.value;
    let email = inputEmail.value;
    let password = inputPass.value;
    let confirmPassword = confirminputpassova.value;
    let role_id = 2;
    if (!username || !email || !password || !confirmPassword) {
        alert("Vui lòng nhập đầy đủ thông tin");
        return;
    }
    if (password !== confirmPassword) {
        alert("Mật khẩu không khớp");
        return;
    }
    if (!email.includes("@")) {
        alert("Email không hợp lệ");
        return;
    }
    if (password.length < 6 || !/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/[0-9]/.test(password)) {
        alert("Mật khẩu phải có ít nhất 6 ký tự, bao gồm chữ hoa, chữ thường và số");
        return;
    }
    createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {

            const user = userCredential.user;

            const userData = {
                uid: user.uid,
                username,
                email,
                role_id,
                balance: 0,
            };

            return addDoc(collection(db, "users"), userData);
        })
        .then(() => {
            alert("Đăng ký thành công");
            window.location.href = "index.html";
        })
        .catch((e) => {
            console.log(e);
            alert("Lỗi: " + e.message);
        });
}
registForm.addEventListener("submit", handleRegister);
