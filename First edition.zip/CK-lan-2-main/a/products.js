import { db } from './config.js';
import {
    collection,
    addDoc,
    getDocs,
    doc,
    updateDoc,
    deleteDoc,
    query,
    orderBy,
    Timestamp
} from "https://www.gstatic.com/firebasejs/12.13.0/firebase-firestore.js";

// ==================== SESSION CHECK ====================
const session = JSON.parse(sessionStorage.getItem("userSession"));
if (!session) {
    window.location.href = "login.html";
}
if (new Date().getTime() > session.expiry) {
    sessionStorage.removeItem("userSession");
    alert("Phiên đăng nhập đã hết hạn");
    window.location.href = "login.html";
}

// Hiển thị email navbar
document.querySelector("#navEmail").textContent = session.user.email;

// Logout
document.querySelector("#logoutBtn").addEventListener("click", () => {
    sessionStorage.removeItem("userSession");
    window.location.href = "login.html";
});


// ==================== STATE ====================
let allProducts = [];       // Toàn bộ sản phẩm từ Firestore
let filteredProducts = [];  // Sản phẩm sau khi filter
let deletingId = null;      // ID sản phẩm đang chờ xóa


// ==================== FIRESTORE COLLECTION ====================
const COLLECTION = "products";


// ==================== FETCH ALL PRODUCTS ====================
const fetchProducts = async () => {
    showLoading(true);
    try {
        const q = query(collection(db, COLLECTION), orderBy("createdAt", "desc"));
        const snapshot = await getDocs(q);
        allProducts = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        applyFilters();
        updateStats();
    } catch (e) {
        // Thử lấy không có orderBy nếu chưa có index
        try {
            const snapshot = await getDocs(collection(db, COLLECTION));
            allProducts = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
            applyFilters();
            updateStats();
        } catch (err) {
            showToast("Lỗi tải dữ liệu: " + err.message, "error");
        }
    } finally {
        showLoading(false);
    }
};


// ==================== RENDER TABLE ====================
const renderTable = (products) => {
    const tbody = document.querySelector("#productTableBody");
    const table = document.querySelector("#productTable");
    const empty = document.querySelector("#emptyState");

    if (products.length === 0) {
        table.style.display = "none";
        empty.style.display = "flex";
        return;
    }

    table.style.display = "table";
    empty.style.display = "none";

    const categoryLabel = {
        coffee: "☕ Cà phê",
        tea: "🍵 Trà",
        juice: "🧃 Nước ép",
        food: "🍰 Đồ ăn",
        other: "🔖 Khác"
    };

    tbody.innerHTML = products.map((p, i) => `
        <tr>
            <td class="td-num">${i + 1}</td>
            <td>
                <div class="product-cell">
                    ${p.imageUrl
                        ? `<img src="${p.imageUrl}" class="product-thumb" onerror="this.style.display='none'" alt="">`
                        : `<div class="product-thumb-placeholder"><i class="fa-solid fa-image"></i></div>`
                    }
                    <span class="product-name">${escapeHtml(p.name)}</span>
                </div>
            </td>
            <td><span class="badge-category">${categoryLabel[p.category] || p.category || "—"}</span></td>
            <td class="td-price">${formatPrice(p.price)}</td>
            <td>
                <span class="badge-status ${p.inStock ? 'in-stock' : 'out-stock'}">
                    ${p.inStock ? '✅ Còn hàng' : '❌ Hết hàng'}
                </span>
            </td>
            <td class="td-desc">${escapeHtml(p.description || "—")}</td>
            <td>
                <div class="action-btns">
                    <button class="btn-edit" onclick="openEdit('${p.id}')">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                    <button class="btn-delete" onclick="openDelete('${p.id}', '${escapeHtml(p.name)}')">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    document.querySelector("#statShowing").textContent = products.length;
};


// ==================== FILTER & SORT ====================
const applyFilters = () => {
    const search = document.querySelector("#searchInput").value.trim().toLowerCase();
    const category = document.querySelector("#categoryFilter").value;
    const status = document.querySelector("#statusFilter").value;
    const sort = document.querySelector("#sortFilter").value;

    filteredProducts = allProducts.filter(p => {
        const matchSearch = !search ||
            p.name?.toLowerCase().includes(search) ||
            p.description?.toLowerCase().includes(search);
        const matchCategory = !category || p.category === category;
        const matchStatus = status === ""
            ? true
            : String(p.inStock) === status;
        return matchSearch && matchCategory && matchStatus;
    });

    // Sort
    if (sort === "price-asc") filteredProducts.sort((a, b) => a.price - b.price);
    else if (sort === "price-desc") filteredProducts.sort((a, b) => b.price - a.price);
    else if (sort === "name-asc") filteredProducts.sort((a, b) => a.name?.localeCompare(b.name));
    else if (sort === "name-desc") filteredProducts.sort((a, b) => b.name?.localeCompare(a.name));

    renderTable(filteredProducts);
    document.querySelector("#statShowing").textContent = filteredProducts.length;
};

// Lắng nghe filter events
["searchInput", "categoryFilter", "statusFilter", "sortFilter"].forEach(id => {
    document.querySelector(`#${id}`).addEventListener("input", applyFilters);
    document.querySelector(`#${id}`).addEventListener("change", applyFilters);
});

document.querySelector("#resetFilter").addEventListener("click", () => {
    document.querySelector("#searchInput").value = "";
    document.querySelector("#categoryFilter").value = "";
    document.querySelector("#statusFilter").value = "";
    document.querySelector("#sortFilter").value = "";
    applyFilters();
});


// ==================== STATS ====================
const updateStats = () => {
    const inStock = allProducts.filter(p => p.inStock).length;
    document.querySelector("#statTotal").textContent = allProducts.length;
    document.querySelector("#statInStock").textContent = inStock;
    document.querySelector("#statOutStock").textContent = allProducts.length - inStock;
};


// ==================== MODAL ADD/EDIT ====================
const productModal = document.querySelector("#productModal");
const modalTitle = document.querySelector("#modalTitle");

const resetForm = () => {
    document.querySelector("#productId").value = "";
    document.querySelector("#productName").value = "";
    document.querySelector("#productPrice").value = "";
    document.querySelector("#productCategory").value = "";
    document.querySelector("#productImage").value = "";
    document.querySelector("#productDesc").value = "";
    document.querySelector("#productStatus").checked = true;
};

// Mở modal thêm
document.querySelector("#openAddModal").addEventListener("click", () => {
    resetForm();
    modalTitle.textContent = "Thêm sản phẩm mới";
    productModal.classList.add("active");
});

// Đóng modal
const closeProductModal = () => {
    productModal.classList.remove("active");
    resetForm();
};
document.querySelector("#closeModal").addEventListener("click", closeProductModal);
document.querySelector("#cancelModal").addEventListener("click", closeProductModal);
productModal.addEventListener("click", (e) => {
    if (e.target === productModal) closeProductModal();
});

// Mở modal sửa (gọi từ onclick trong table)
window.openEdit = (id) => {
    const product = allProducts.find(p => p.id === id);
    if (!product) return;

    document.querySelector("#productId").value = product.id;
    document.querySelector("#productName").value = product.name || "";
    document.querySelector("#productPrice").value = product.price || "";
    document.querySelector("#productCategory").value = product.category || "";
    document.querySelector("#productImage").value = product.imageUrl || "";
    document.querySelector("#productDesc").value = product.description || "";
    document.querySelector("#productStatus").checked = product.inStock !== false;

    modalTitle.textContent = "Chỉnh sửa sản phẩm";
    productModal.classList.add("active");
};


// ==================== SAVE (ADD / UPDATE) ====================
document.querySelector("#saveProduct").addEventListener("click", async () => {
    const id = document.querySelector("#productId").value;
    const name = document.querySelector("#productName").value.trim();
    const price = parseFloat(document.querySelector("#productPrice").value);
    const category = document.querySelector("#productCategory").value;
    const imageUrl = document.querySelector("#productImage").value.trim();
    const description = document.querySelector("#productDesc").value.trim();
    const inStock = document.querySelector("#productStatus").checked;

    // Validation
    if (!name) { showToast("Vui lòng nhập tên sản phẩm", "error"); return; }
    if (!price || price <= 0) { showToast("Vui lòng nhập giá hợp lệ", "error"); return; }
    if (!category) { showToast("Vui lòng chọn danh mục", "error"); return; }

    const saveBtn = document.querySelector("#saveProduct");
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Đang lưu...';

    const data = { name, price, category, imageUrl, description, inStock };

    try {
        if (id) {
            // UPDATE
            await updateDoc(doc(db, COLLECTION, id), data);
            showToast("Cập nhật sản phẩm thành công!", "success");
        } else {
            // ADD
            data.createdAt = Timestamp.now();
            await addDoc(collection(db, COLLECTION), data);
            showToast("Thêm sản phẩm thành công!", "success");
        }
        closeProductModal();
        await fetchProducts();
    } catch (e) {
        showToast("Lỗi: " + e.message, "error");
    } finally {
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Lưu';
    }
});


// ==================== DELETE ====================
const deleteModal = document.querySelector("#deleteModal");

window.openDelete = (id, name) => {
    deletingId = id;
    document.querySelector("#deleteProductName").textContent = name;
    deleteModal.classList.add("active");
};

const closeDeleteModal = () => {
    deleteModal.classList.remove("active");
    deletingId = null;
};
document.querySelector("#closeDeleteModal").addEventListener("click", closeDeleteModal);
document.querySelector("#cancelDelete").addEventListener("click", closeDeleteModal);
deleteModal.addEventListener("click", (e) => {
    if (e.target === deleteModal) closeDeleteModal();
});

document.querySelector("#confirmDelete").addEventListener("click", async () => {
    if (!deletingId) return;

    const confirmBtn = document.querySelector("#confirmDelete");
    confirmBtn.disabled = true;
    confirmBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

    try {
        await deleteDoc(doc(db, COLLECTION, deletingId));
        showToast("Đã xóa sản phẩm!", "success");
        closeDeleteModal();
        await fetchProducts();
    } catch (e) {
        showToast("Lỗi: " + e.message, "error");
    } finally {
        confirmBtn.disabled = false;
        confirmBtn.innerHTML = '<i class="fa-solid fa-trash"></i> Xóa';
    }
});


// ==================== HELPERS ====================
const showLoading = (state) => {
    document.querySelector("#loadingState").style.display = state ? "flex" : "none";
    if (state) {
        document.querySelector("#productTable").style.display = "none";
        document.querySelector("#emptyState").style.display = "none";
    }
};

const formatPrice = (price) => {
    if (!price && price !== 0) return "—";
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency', currency: 'VND'
    }).format(price);
};

const escapeHtml = (str) => {
    if (!str) return "";
    return str.replace(/&/g, "&amp;")
              .replace(/</g, "&lt;")
              .replace(/>/g, "&gt;")
              .replace(/"/g, "&quot;")
              .replace(/'/g, "&#039;");
};

const showToast = (message, type = "success") => {
    const container = document.querySelector("#toastContainer");
    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <i class="fa-solid ${type === 'success' ? 'fa-circle-check' : 'fa-circle-xmark'}"></i>
        <span>${message}</span>
    `;
    container.appendChild(toast);
    setTimeout(() => toast.classList.add("show"), 10);
    setTimeout(() => {
        toast.classList.remove("show");
        setTimeout(() => toast.remove(), 400);
    }, 3500);
};


// ==================== INIT ====================
fetchProducts();
