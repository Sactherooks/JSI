import { initializeApp } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-analytics.js";

import { getAuth } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyDxa3ZE9vKcGjRRBd9rCeBRw7d-d3CVnhk",
    authDomain: "fir-cafe-a6eb7.firebaseapp.com",
    projectId: "fir-cafe-a6eb7",
    storageBucket: "fir-cafe-a6eb7.firebasestorage.app",
    messagingSenderId: "17973464143",
    appId: "1:17973464143:web:96b613e13e37ad06f5ee3a",
    measurementId: "G-87WY9GKXBT"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);
const db = getFirestore(app);

export {auth, db};
